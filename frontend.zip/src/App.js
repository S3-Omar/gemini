import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LoginPage from './components/LoginPage'; // Asegúrate de que la ruta sea correcta
import RegisterPage from './components/RegisterPage'; // Asegúrate de que la ruta sea correcta
import Dashboard from './components/Dashboard';
import Menu from './components/MesaMenu';
import CartaMenu from './components/CartaMenu';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<LoginPage />} /> {/* Usamos 'element' en lugar de 'component' */}
          <Route path="/register" element={<RegisterPage />} /> {/* También 'element' aquí */}
          <Route path="/dashboard" element={<Dashboard />} /> {/* dashboard */}
          <Route path="/menu" element={<Menu />} /> {/* menu */}
          <Route path="/carta-menu" element={<CartaMenu />} /> {/* menu */}
        </Routes>
      </div>
    </Router>
  );
}

export default App;

import React, { useState } from "react";
import "../styles/Dashboard.css";
import MesaMenu from "./MesaMenu";

const Dashboard = () => {
    const [menuVisible, setMenuVisible] = useState(true);
    const [mesas, setMesas] = useState([
        { id: 1, nombre: "Mesa 1", x: 50, y: 50, estado: 0 },
        { id: 2, nombre: "Mesa 2", x: 200, y: 100, estado: 0 },
    ]);
    const [draggingMesa, setDraggingMesa] = useState(null);
    const [isDragging, setIsDragging] = useState(false);
    const [offset, setOffset] = useState({ x: 0, y: 0 });
    const [deleteMode, setDeleteMode] = useState(false);
    const [selectedMesa, setSelectedMesa] = useState(null);

    const handleMouseDown = (e, mesa) => {
        setDraggingMesa(mesa.id);
        setOffset({ x: e.clientX - mesa.x, y: e.clientY - mesa.y });
        setIsDragging(false); // Inicializar como "no arrastrando"
    };

    const handleMouseMove = (e) => {
        if (draggingMesa) {
            setIsDragging(true); // Cambiar a "arrastrando"
            setMesas((prevMesas) =>
                prevMesas.map((mesa) =>
                    mesa.id === draggingMesa
                        ? { ...mesa, x: e.clientX - offset.x, y: e.clientY - offset.y }
                        : mesa
                )
            );
        }
    };

    const handleMouseUp = () => {
        setDraggingMesa(null);
    };

    const handleMesaClick = (mesa) => {
        if (!isDragging) {
            setSelectedMesa(mesa); // Solo abrir el menú si no se está arrastrando
        }
    };

    const handleDeleteMesa = (e, id) => {
        e.stopPropagation(); // Evitar propagación del evento al contenedor padre
        setMesas(mesas.filter((mesa) => mesa.id !== id));
    };

    return (
        <div
            className="dashboard"
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
        >
            <div className={`sidebar ${menuVisible ? "" : "hidden"}`}>
                <button
                    className="toggle-btn"
                    onClick={() => setMenuVisible(!menuVisible)}
                >
                    {menuVisible ? "<<" : ">>"}
                </button>
                <div className="menu">
                    <h3>Menú</h3>
                    <ul>
                        <li>Gestión de Mesas</li>
                        <li>Gestión de Pedidos</li>
                        <li>Reportes</li>
                        <li>Configuraciones</li>
                    </ul>
                </div>
            </div>

            <div className="main-area">
                <h2>Gestión de Mesas</h2>
                <div className="controls">
                    <button
                        className="control-btn add"
                        onClick={() =>
                            setMesas([
                                ...mesas,
                                {
                                    id: mesas.length + 1,
                                    nombre: `Mesa ${mesas.length + 1}`,
                                    x: 100,
                                    y: 100,
                                    estado: 0,
                                },
                            ])
                        }
                    >
                        <span className="icon">+</span>
                    </button>
                    <button
                        className={`control-btn delete ${deleteMode ? "active" : ""}`}
                        onClick={() => setDeleteMode(!deleteMode)}
                    >
                        <span className="icon">-</span>
                    </button>
                </div>

                <div className="mesas-area">
                    {mesas.map((mesa) => (
                        <div
                            key={mesa.id}
                            className="mesa"
                            style={{
                                left: `${mesa.x}px`,
                                top: `${mesa.y}px`,
                            }}
                            onMouseDown={(e) => handleMouseDown(e, mesa)}
                            onMouseUp={handleMouseUp}
                            onClick={() => handleMesaClick(mesa)}
                        >
                            <img
                                src="https://cdn-icons-png.flaticon.com/512/1047/1047026.png"
                                alt={mesa.nombre}
                            />
                            <p>{mesa.nombre}</p>

                            {deleteMode && (
                                <button
                                    className="remove-btn"
                                    onClick={(e) => handleDeleteMesa(e, mesa.id)}
                                >
                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        viewBox="0 0 512 512"
                                        className="delete-icon"
                                        fill="currentColor"
                                    >
                                        <path d="M135 0h242c13.2 0 24 10.8 24 24v40h96c13.2 0 24 10.8 24 24s-10.8 24-24 24H487l-23.7 392.7c-1.2 19.6-17.6 35.3-37.3 35.3H86c-19.7 0-36.1-15.7-37.3-35.3L25 112H24c-13.2 0-24-10.8-24-24s10.8-24 24-24h96V24c0-13.2 10.8-24 24-24zm216 64V48H161v16h190zm-59 370c6.6 0 12-5.4 12-12V204c0-6.6-5.4-12-12-12s-12 5.4-12 12v218c0 6.6 5.4 12 12 12zm-114 0c6.6 0 12-5.4 12-12V204c0-6.6-5.4-12-12-12s-12 5.4-12 12v218c0 6.6 5.4 12 12 12z" />
                                    </svg>
                                </button>
                            )}
                        </div>
                    ))}
                </div>
            </div>

            {selectedMesa && (
                <MesaMenu
                    mesa={selectedMesa}
                    onClose={() => setSelectedMesa(null)}
                    onSave={(updatedMesa) =>
                        setMesas((prevMesas) =>
                            prevMesas.map((mesa) =>
                                mesa.id === updatedMesa.id ? updatedMesa : mesa
                            )
                        )
                    }
                />
            )}
        </div>
    );
};

export default Dashboard;

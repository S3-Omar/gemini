import React, { useState, useEffect } from "react";
import axios from "axios";
import "../styles/CartaMenu.css"; // Archivo CSS separado

const categories = ["Marina", "Criolla", "Parrillas", "Bebidas", "Promociones"];

const CartaMenu = () => {
  const [selectedCategory, setSelectedCategory] = useState(categories[0]);
  const [products, setProducts] = useState([]);
  const [editingProduct, setEditingProduct] = useState(null);
  const [formData, setFormData] = useState({
    id: "",
    nombre: "",
    descripcion: "",
    precios: { personal: null, mediano: null, familiar: null },
    imagen: null,
  });
  const [isAdding, setIsAdding] = useState(false); // Estado para controlar la ventana de añadir

  const baseUrl = process.env.REACT_APP_BACKEND_URL || "http://localhost:5000";

  useEffect(() => {
    fetchProducts();
  }, [selectedCategory]);

  const fetchProducts = async () => {
    try {
      const response = await axios.get(`${baseUrl}/cartamenu/${selectedCategory.toLowerCase()}`);
      setProducts(response.data.productos || []);
    } catch (error) {
      console.error("Error fetching products:", error);
    }
  };

  const handleEditClick = (product) => {
    setEditingProduct(product.id);
    setFormData({
      id: product.id,
      nombre: product.nombre,
      descripcion: product.descripcion,
      precios: product.precios,
      imagen: product.imagen,
    });
  };

  const handleAddClick = () => {
    setIsAdding(true); // Mostrar el formulario para añadir
    setFormData({
      id: "",
      nombre: "",
      descripcion: "",
      precios: { personal: null, mediano: null, familiar: null },
      imagen: null,
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handlePriceChange = (size, value) => {
    setFormData({
      ...formData,
      precios: { ...formData.precios, [size]: parseFloat(value) },
    });
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file && ["image/png", "image/jpg", "image/jpeg"].includes(file.type)) {
      const reader = new FileReader();
      reader.onload = () => {
        setFormData({ ...formData, imagen: reader.result.split(",")[1] }); // Eliminar el prefijo 'data:image/...;base64,'
      };
      reader.readAsDataURL(file);
    } else {
      alert("Por favor, selecciona una imagen válida (PNG, JPG, JPEG).");
    }
  };

  const handleSave = async () => {
    try {
      // Limpiamos los precios que sean nulos
      const dataToSave = {
        ...formData,
        precios: cleanPrices(formData.precios),
        id: formData.id || Date.now().toString(), // Generamos un ID único si no está presente
      };

      if (isAdding) {
        // Si estamos añadiendo, llamamos al API para agregar un nuevo producto
        await axios.post(`${baseUrl}/cartamenu/${selectedCategory.toLowerCase()}`, dataToSave);
        setIsAdding(false); // Cerrar el modal después de guardar
      } else {
        // Si estamos editando, actualizamos el producto
        await axios.put(`${baseUrl}/cartamenu/${selectedCategory.toLowerCase()}`, dataToSave);
      }

      fetchProducts();
      setEditingProduct(null);
      setFormData({
        id: "",
        nombre: "",
        descripcion: "",
        precios: { personal: null, mediano: null, familiar: null },
        imagen: null,
      });
    } catch (error) {
      console.error("Error saving product:", error);
    }
  };

  const handleDelete = async (productId) => {
    try {
      // Llamada al backend para eliminar el producto
      const response = await axios.delete(`${baseUrl}/cartamenu/${selectedCategory.toLowerCase()}/${productId}`);
      
      if (response.status === 200) {
        // Si la eliminación fue exitosa, actualizamos la lista de productos
        setProducts((prevProducts) => prevProducts.filter((product) => product.id !== productId));
      } else {
        console.error("Error al eliminar el producto:", response);
      }
    } catch (error) {
      console.error("Error deleting product:", error);
    }
  };

  // Elimina los precios que sean null
  const cleanPrices = (prices) => {
    const cleanedPrices = { ...prices };
    Object.keys(cleanedPrices).forEach((key) => {
      if (cleanedPrices[key] == null) {
        delete cleanedPrices[key];
      }
    });
    return cleanedPrices;
  };

  return (
    <div className="carta-menu">
      <h1>Carta Menú</h1>
      <div className="category-selector">
        <label htmlFor="category">Selecciona una categoría:</label>
        <select
          id="category"
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
        >
          {categories.map((category) => (
            <option key={category} value={category}>
              {category}
            </option>
          ))}
        </select>
      </div>

      <div className="product-list">
        {products.map((product) => (
          <div className="product-card" key={product.id}>
            <img
              src={`data:image/jpeg;base64,${product.imagen}`}
              alt={product.nombre}
              className="product-image"
              style={{ width: 200, height: 200, objectFit: "cover" }}
            />
            {editingProduct === product.id ? (
              <div className="product-edit-form">
                <input
                  type="text"
                  name="nombre"
                  value={formData.nombre}
                  onChange={handleInputChange}
                  placeholder="Nombre del producto"
                />
                <textarea
                  name="descripcion"
                  value={formData.descripcion}
                  onChange={handleInputChange}
                  placeholder="Descripción"
                />
                <div className="price-inputs">
                  <div>
                    <label>Personal:</label>
                    <input
                      type="number"
                      name="personal"
                      value={formData.precios.personal}
                      onChange={(e) => handlePriceChange("personal", e.target.value)}
                    />
                  </div>
                  <div>
                    <label>Mediano:</label>
                    <input
                      type="number"
                      name="mediano"
                      value={formData.precios.mediano}
                      onChange={(e) => handlePriceChange("mediano", e.target.value)}
                    />
                  </div>
                  <div>
                    <label>Familiar:</label>
                    <input
                      type="number"
                      name="familiar"
                      value={formData.precios.familiar}
                      onChange={(e) => handlePriceChange("familiar", e.target.value)}
                    />
                  </div>
                </div>
                <input
                  type="file"
                  accept=".png,.jpg,.jpeg"
                  onChange={handleImageChange}
                />
                <button onClick={handleSave}>Guardar</button>
              </div>
            ) : (
              <div className="product-details">
                <h3>{product.nombre}</h3>
                <p>{product.descripcion}</p>
                <ul>
                  {Object.entries(product.precios).map(([size, price]) => (
                    <li key={size}>
                      {size.charAt(0).toUpperCase() + size.slice(1)}: S/{price}
                    </li>
                  ))}
                </ul>
                <button onClick={() => handleEditClick(product)}>
                  ✏️ Editar
                </button>
                <button onClick={() => handleDelete(product.id)}>
                  🗑️ Eliminar
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Modal de Añadir Producto */}
      {isAdding && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h2>Agregar Nuevo Producto</h2>
            <input
              type="text"
              name="nombre"
              value={formData.nombre}
              onChange={handleInputChange}
              placeholder="Nombre del producto"
            />
            <textarea
              name="descripcion"
              value={formData.descripcion}
              onChange={handleInputChange}
              placeholder="Descripción"
            />
            <div className="price-inputs">
              <div>
                <label>Personal:</label>
                <input
                  type="number"
                  name="personal"
                  value={formData.precios.personal}
                  onChange={(e) => handlePriceChange("personal", e.target.value)}
                />
              </div>
              <div>
                <label>Mediano:</label>
                <input
                  type="number"
                  name="mediano"
                  value={formData.precios.mediano}
                  onChange={(e) => handlePriceChange("mediano", e.target.value)}
                />
              </div>
              <div>
                <label>Familiar:</label>
                <input
                  type="number"
                  name="familiar"
                  value={formData.precios.familiar}
                  onChange={(e) => handlePriceChange("familiar", e.target.value)}
                />
              </div>
            </div>
            <input
              type="file"
              accept=".png,.jpg,.jpeg"
              onChange={handleImageChange}
            />
            <button onClick={handleSave}>Guardar</button>
            <button onClick={() => setIsAdding(false)}>Cancelar</button>
          </div>
        </div>
      )}
      
      <button className="add-product-btn" onClick={handleAddClick}>
        Añadir Producto
      </button>
    </div>
  );
};

export default CartaMenu;

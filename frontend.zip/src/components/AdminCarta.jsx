import React, { useState, useEffect } from "react";

const AdminCarta = () => {
  const [categorias, setCategorias] = useState([]);
  const [selectedCategoria, setSelectedCategoria] = useState("");
  const [productos, setProductos] = useState([]);
  const [editingProducto, setEditingProducto] = useState(null);

  const [nuevoProducto, setNuevoProducto] = useState({
    nombre: "",
    descripcion: "",
    imagen: "",
    precios: {},
  });

  // Obtener las categorías y productos
  useEffect(() => {
    fetch("http://localhost:5000/cartamenu")
      .then((res) => res.json())
      .then((data) => setCategorias(data))
      .catch((err) => console.error(err));
  }, []);

  const handleCategoriaChange = (categoria) => {
    setSelectedCategoria(categoria);
    const categoriaData = categorias.find((cat) => cat.categoria === categoria);
    setProductos(categoriaData ? categoriaData.productos : []);
  };

  // Guardar cambios en un producto
  const handleSaveProducto = (producto) => {
    fetch(`http://localhost:5000/cartamenu/${producto.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ categoria: selectedCategoria, producto }),
    })
      .then((res) => res.json())
      .then(() => alert("Producto actualizado"))
      .catch((err) => console.error(err));
  };

  // Agregar un nuevo producto
  const handleAddProducto = () => {
    fetch("http://localhost:5000/cartamenu", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        categoria: selectedCategoria,
        nuevoProducto: nuevoProducto,
      }),
    })
      .then((res) => res.json())
      .then(() => {
        alert("Producto agregado");
        setNuevoProducto({
          nombre: "",
          descripcion: "",
          imagen: "",
          precios: {},
        });
      })
      .catch((err) => console.error(err));
  };

  return (
    <div>
      <h1>Administrar Carta</h1>
      <select onChange={(e) => handleCategoriaChange(e.target.value)}>
        <option value="">Seleccionar Categoría</option>
        {categorias.map((cat) => (
          <option key={cat.categoria} value={cat.categoria}>
            {cat.categoria}
          </option>
        ))}
      </select>

      {productos.map((producto) => (
        <div key={producto.id}>
          {editingProducto === producto.id ? (
            <div>
              <input
                type="text"
                value={producto.nombre}
                onChange={(e) =>
                  setEditingProducto({
                    ...producto,
                    nombre: e.target.value,
                  })
                }
              />
              <button onClick={() => handleSaveProducto(producto)}>Guardar</button>
            </div>
          ) : (
            <div>
              <p>{producto.nombre}</p>
              <button onClick={() => setEditingProducto(producto.id)}>
                Editar
              </button>
            </div>
          )}
        </div>
      ))}

      <h2>Agregar Producto</h2>
      <input
        type="text"
        placeholder="Nombre"
        value={nuevoProducto.nombre}
        onChange={(e) =>
          setNuevoProducto({ ...nuevoProducto, nombre: e.target.value })
        }
      />
      <textarea
        placeholder="Descripción"
        value={nuevoProducto.descripcion}
        onChange={(e) =>
          setNuevoProducto({ ...nuevoProducto, descripcion: e.target.value })
        }
      />
      <input
        type="text"
        placeholder="URL Imagen"
        value={nuevoProducto.imagen}
        onChange={(e) =>
          setNuevoProducto({ ...nuevoProducto, imagen: e.target.value })
        }
      />
      <button onClick={handleAddProducto}>Agregar</button>
    </div>
  );
};

export default AdminCarta;

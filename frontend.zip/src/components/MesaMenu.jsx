import React, { useState, useEffect } from "react";
import "../styles/MesaMenu.css";

const MesaMenu = ({ mesa, onClose, onSave }) => {
  const [mesero, setMesero] = useState("");
  const [resumenPedido, setResumenPedido] = useState([]);
  const [estadoMesa, setEstadoMesa] = useState(mesa?.estado || 0);
  const [isVisible, setIsVisible] = useState(false); // Nuevo estado para animación de apertura

  // Hacer visible el menú al montarse el componente
  useEffect(() => {
    setIsVisible(true);
  }, []);

  const handleSave = (estado) => {
    const updatedMesa = {
      ...mesa,
      mesero,
      resumenPedido,
      estado,
      hora_ingreso: estado === 1 ? new Date().toISOString() : mesa.hora_ingreso,
      hora_fin: estado === 0 ? new Date().toISOString() : null,
    };
    onSave(updatedMesa);
    onClose();
  };

  return (
    <div className={`mesa-menu-overlay ${isVisible ? "show" : ""}`}>
      <div className="mesa-menu">
        {/* Cerrar el menú - la "X" dentro del contenedor del menú */}
        <button className="close-btn" onClick={onClose}>
          &times;
        </button>

        <h3>Mesa {mesa.nombre}</h3>
        <div>
          <label htmlFor="mesero">Mesero:</label>
          <select
            id="mesero"
            value={mesero}
            onChange={(e) => setMesero(e.target.value)}
          >
            <option value="">Seleccionar Mesero</option>
            <option value="Juan Pérez">Juan Pérez</option>
            <option value="María López">María López</option>
            <option value="Carlos Gómez">Carlos Gómez</option>
          </select>
        </div>
        <div>
          <button
            className="menu-btn"
            onClick={() => alert("Ir al Menú (redirección pendiente)")}
          >
            Ir al Menú
          </button>
        </div>
        <div className="resumen-pedido">
          <h4>Resumen del Pedido</h4>
          {resumenPedido.length > 0 ? (
            <ul>
              {resumenPedido.map((item, index) => (
                <li key={index}>
                  {item.platillo} - {item.cantidad}
                </li>
              ))}
            </ul>
          ) : (
            <p>No hay pedidos aún.</p>
          )}
        </div>
        <div className="mesa-actions">
          <button onClick={() => handleSave(1)}>Atendiendo</button>
          <button onClick={() => handleSave(0)}>Boleta</button>
          <button onClick={() => handleSave(0)}>Cancelar</button>
        </div>
      </div>
    </div>
  );
};

export default MesaMenu;

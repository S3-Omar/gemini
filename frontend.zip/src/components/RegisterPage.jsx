import React, { useState } from 'react';
import axios from 'axios';
import '../styles/RegisterPage.css';
import fondoImage from '../images/register.png';
import { Link } from 'react-router-dom';

const RegisterPage = () => {
  const [usuario, setUsuario] = useState('');
  const [contraseña, setContraseña] = useState('');
  const [user_name, setUserName] = useState('');
  const [user_lastname, setUserLastname] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleRegister = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post(`${process.env.REACT_APP_API_URL}/register`, {
        usuario,
        contraseña,
        user_name,
        user_lastname,
      });

      if (response.data.success) {
        setSuccess('¡Registro exitoso! Ahora puedes iniciar sesión.');
        setUsuario('');
        setContraseña('');
        setUserName('');
        setUserLastname('');
        setError('');
      }
    } catch (err) {
      setError('Hubo un problema al registrar el usuario. Intenta nuevamente.');
    }
  };

  return (
    <div className="register-container">
      <div className="register-box">
        <h2>Registrarse</h2>
        <form onSubmit={handleRegister}>
          <input
            type="text"
            placeholder="Usuario"
            value={usuario}
            onChange={(e) => setUsuario(e.target.value)}
          />
          <input
            type="password"
            placeholder="Contraseña"
            value={contraseña}
            onChange={(e) => setContraseña(e.target.value)}
          />
          <input
            type="text"
            placeholder="Nombre"
            value={user_name}
            onChange={(e) => setUserName(e.target.value)}
          />
          <input
            type="text"
            placeholder="Apellido"
            value={user_lastname}
            onChange={(e) => setUserLastname(e.target.value)}
          />
          {error && <p className="error-message">{error}</p>}
          {success && <p className="success-message">{success}</p>}
          <button type="submit">Registrar</button>
        </form>
      </div>
    </div>
  );
};

export default RegisterPage;

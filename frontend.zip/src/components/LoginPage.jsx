import React, { useState } from 'react';
import axios from 'axios';
import '../styles/LoginPage.css';
import fondoImage from '../images/fondo.png'; // Asegúrate de que el nombre y la ruta sean correctos
import { Link } from 'react-router-dom'; // Importa Link para la navegación

const LoginPage = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
        const response = await axios.post(`${process.env.REACT_APP_API_URL}/login`, {
            usuario: username,
            contraseña: password,
          });

      console.log('Respuesta del backend:', response.data); // Verifica la respuesta

      if (response.data.success) {
        alert(`¡Bienvenido, ${response.data.usuario}!`);
        // Aquí puedes redirigir al dashboard o guardar el token en el localStorage
      } else {
        setError(response.data.message || 'Error desconocido');
      }
    } catch (err) {
      console.error('Error en la solicitud:', err); // Verifica el error en la consola
      setError('Hubo un error en la solicitud.');
    }
  };

  return (
    <div className="login-container" style={{ backgroundImage: `url(${fondoImage})` }}>
      <div className="login-box">
        <div className="login-logo">
          <img src="/chef-logo.png" alt="Chef Logo" />
        </div>
        <h2>Iniciar Sesión</h2>
        <form onSubmit={handleLogin}>
          <input
            type="text"
            placeholder="Usuario"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <input
            type="password"
            placeholder="Contraseña"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          {error && <p className="error-message">{error}</p>}
          <button type="submit">Entrar</button>
        </form>
        {/* Enlace para redirigir a la página de registro */}
        <p>
          ¿No tienes cuenta? <Link to="/register">Regístrate aquí</Link>
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
